# 🎮 [FD] StreamMayham – Safe Use Guide

This toolkit lets your Twitch viewers trigger fun chaos effects (mouse spins, fake crashes, input blocking, and more) using tools like **Streamer.bot** or a web browser trigger system.


=================================================================================================================================================================
                                             ✅ How It Works

=================================================================================================================================================================

These effects are built as **external applications** using C#. They:
- Simulate input (e.g., mouse movement, clicks)
- Modify cursor behavior
- Trigger visual effects (e.g., fake crash , jumpscares)
- Never inject into games or modify memory



## 🛡️ Safe Use with Anti-Cheat Systems

This project was designed with **streamer safety in mind**.

| Safe Practices ✔️                         | Avoid ❌                            |
|--------------------------------------------|-------------------------------------|
| Run effects as separate `.exe` files       | Injecting code into game processes  |
| Use tools like Streamer.bot to trigger     | Writing memory of the game process  |
| Keep durations short & clearly triggered   | Emulating precise aim/timing macros |
| Effects visible/audible (stream safe)      | Masking actions to look like cheating|




=================================================================================================================================
                                             ⚠️ Confirmed Games Safe With These Anti-Cheats:
=================================================================================================================================

> These are safe because the effects **don’t interact with the game directly**, and resemble accessibility tools or input automation used by streamers.

**EasyAntiCheat**

   Rust
   Hunt: Showdown
   Apex Legends

**BattlEye**

   PUBG

=================================================================================================================================
                                             ⚠️ Confirmed Games Safe Without Anti-Cheats:
=================================================================================================================================

- Paranormal Cleanup



=================================================================================================================================
                                             ⚠️ Confirmed Games NOT working:
=================================================================================================================================

- Rocket league





## This list will expand over time when we test more and more games



=================================================================================================================================
                                                         🔧 Tips for Safe Use
=================================================================================================================================




1. **Run As Administrator**  
   Some effects (like input blocking or audio mute) require admin privileges.

2. **Avoid During Competitive Moments**  
   Don't trigger effects while actively engaging in combat — it could be misinterpreted by anti-cheat systems if they coincide with precise input.

3. **Use Cooldowns**  
   Set cooldowns in Streamer.bot (or your web trigger system) to prevent rapid or overlapping effects.

4. **Use a "Safe Mode" Toggle**  
   Add a global disable/hotkey in case you need to instantly stop effects.

5. **Be Transparent**  
   Let your audience know the effects are for fun, and they're triggering them. This builds trust and shows intent.



=================================================================================================================================================================
                                                         🚀 Setup Overview
=================================================================================================================================================================


1. **Set up Streamer.bot**
 
 - Make sure the exe's are set to run as admin
- Create a new action
- As trigger make a channel point/bit or command
- In subaction go to Core > System > Run program
And here select the exe you want to use



=================================================================================================================================================================
                                                         ⚠️ Final Notes
=================================================================================================================================================================


This toolkit is **not a cheat or exploit** — it's meant for stream entertainment. Effects are external, lightweight, and fun. Always stay within safe usage guidelines and avoid using these tools to gain competitive advantage.



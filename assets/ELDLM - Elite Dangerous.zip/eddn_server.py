import zmq
import zlib
import json
import threading
from flask import Flask, jsonify, render_template

# --- Global store for markets ---
latest_markets = {}

# --- Flask app ---
app = Flask(__name__)

def eddn_listener():
    """Listen to EDDN for commodity market data and store the latest info."""
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    socket.connect("tcp://eddn.edcd.io:9500")
    socket.setsockopt_string(zmq.SUBSCRIBE, "")

    print("Listening to EDDN stream...")

    while True:
        try:
            message = socket.recv()
            data = zlib.decompress(message)
            msg_json = json.loads(data)

            schema = msg_json.get("$schemaRef", "")

            if "commodity" in schema:
                sys_name = msg_json["message"]["systemName"]
                station_name = msg_json["message"]["stationName"]
                commodities = msg_json["message"].get("commodities", [])

                key = f"{sys_name} - {station_name}"
                latest_markets[key] = commodities
        except Exception as e:
            print("Listener error:", e)

# --- API endpoint ---
@app.route("/api/markets")
def markets():
    """Return all latest market data as JSON."""
    return jsonify(latest_markets)

# --- Serve the market data HTML page ---
@app.route("/market_data")
def market_page():
    return render_template("market_data.html")

if __name__ == "__main__":
    threading.Thread(target=eddn_listener, daemon=True).start()
    app.run(port=5000)
##This reshade shader is made available under the terms of the  BSD-style license that can be found in the LICENSE file in the root directory##
©Copyright 2023 Fusion Entertainment

**HOW TO INSTALL**

To install this do the following,

1. Install Reshade software with this link:
https://reshade.me/

2. after the reshade is installed trop the profiles folder in the following location
Steam\steamapps\common\Cyberpunk 2077\bin\x64

3. After this launch the game and select the profile

does it not work or you can find out how to make it work properly
contect me true https://www.flockers-design.com

or join our discord also found on the website

and we will be there to help

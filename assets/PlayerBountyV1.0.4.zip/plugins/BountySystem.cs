using System;
using System.Collections.Generic;
using Oxide.Core;
using Oxide.Core.Plugins;
using Oxide.Core.Libraries.Covalence;
using Oxide.Core.Libraries;      // <-- Added for RequestMethod
using Newtonsoft.Json;

namespace Oxide.Plugins
{
    [Info("BountySystem", "FlockersDesign", "1.0.4")]
    [Description("Allows players to place bounties on others using scrap.")]
    public class BountySystem : CovalencePlugin
    {
        private ConfigData config;
        private Dictionary<string, Bounty> bounties = new();
        private Dictionary<string, DateTime> cooldowns = new();
        private Dictionary<string, int> pendingRewards = new();

        private class ConfigData
        {
            public int MinBounty { get; set; } = 50;
            public int MaxBounty { get; set; } = 2000;
            public int CooldownSeconds { get; set; } = 300;
            public string RewardItemShortname { get; set; } = "scrap";
            public bool RequireTargetOnline { get; set; } = true;
            public string WebhookUrl { get; set; } = "";
        }

        private class Bounty
        {
            public string TargetId;
            public string TargetName;
            public int RewardAmount;
        }

        protected override void LoadDefaultConfig() => config = new ConfigData();

        private void Init()
        {
            config = Config.ReadObject<ConfigData>();
            Config.WriteObject(config, true);
        }

        [Command("bounty")]
        private void CmdBounty(IPlayer player, string command, string[] args)
        {
            if (args.Length == 0)
            {
                player.Reply("<color=orange>Usage:</color> /bounty add <name> <amount> | /bounties | /bounty info <name>");
                return;
            }

            switch (args[0].ToLower())
            {
                case "add":
                    if (args.Length < 3)
                    {
                        player.Reply("<color=red>Usage:</color> /bounty add <player> <amount>");
                        return;
                    }
                    HandleAddBounty(player, args[1], args[2]);
                    break;

                case "info":
                    if (args.Length < 2)
                    {
                        player.Reply("<color=red>Usage:</color> /bounty info <player>");
                        return;
                    }
                    HandleInfo(player, args[1]);
                    break;

                default:
                    HandleList(player);
                    break;
            }
        }

        private void HandleAddBounty(IPlayer issuer, string targetName, string amountStr)
        {
            if (!int.TryParse(amountStr, out int amount))
            {
                issuer.Reply("<color=red>Invalid amount.</color>");
                return;
            }

            if (amount < config.MinBounty || amount > config.MaxBounty)
            {
                issuer.Reply($"<color=red>Amount must be between {config.MinBounty} and {config.MaxBounty} scrap.</color>");
                return;
            }

            if (cooldowns.TryGetValue(issuer.Id, out var last) && (DateTime.UtcNow - last).TotalSeconds < config.CooldownSeconds)
            {
                double remaining = config.CooldownSeconds - (DateTime.UtcNow - last).TotalSeconds;
                issuer.Reply($"<color=red>You must wait {Math.Ceiling(remaining)}s before placing another bounty.</color>");
                return;
            }

            IPlayer target = players.FindPlayer(targetName);
            if (target == null || (config.RequireTargetOnline && !target.IsConnected))
            {
                issuer.Reply("<color=red>Target player not found or not online.</color>");
                return;
            }

            if (issuer.Id == target.Id && !issuer.IsAdmin)
            {
                issuer.Reply("<color=red>Only admins can place bounties on themselves.</color>");
                return;
            }

            var basePlayer = issuer.Object as BasePlayer;
            if (basePlayer == null || basePlayer.inventory == null)
                return;

            var itemDef = ItemManager.FindItemDefinition(config.RewardItemShortname);
            if (itemDef == null)
            {
                issuer.Reply("<color=red>Invalid item configured for bounties.</color>");
                return;
            }

            int totalScrap = basePlayer.inventory.GetAmount(itemDef.itemid);
            if (totalScrap < amount)
            {
                issuer.Reply("<color=red>You don’t have enough scrap.</color>");
                return;
            }

            basePlayer.inventory.Take(null, itemDef.itemid, amount);
            basePlayer.Command("note.inv", itemDef.itemid, -amount);

            bounties[target.Id] = new Bounty
            {
                TargetId = target.Id,
                TargetName = target.Name,
                RewardAmount = amount
            };

            cooldowns[issuer.Id] = DateTime.UtcNow;

            server.Broadcast($"<color=red>[BOUNTY]</color> {issuer.Name} placed a bounty of {amount} scrap on {target.Name}!");
            SendDiscordEmbed("🔴 Bounty Placed", $"**{issuer.Name}** placed a bounty of **{amount} scrap** on **{target.Name}**.", "FF0000");
        }

        private void HandleInfo(IPlayer player, string targetName)
        {
            IPlayer target = players.FindPlayer(targetName);
            if (target == null)
            {
                player.Reply("<color=red>Player not found.</color>");
                return;
            }

            if (bounties.TryGetValue(target.Id, out var bounty))
            {
                player.Reply($"<color=yellow>{bounty.TargetName}</color> has a bounty of <color=orange>{bounty.RewardAmount}</color> scrap.");
            }
            else
            {
                player.Reply("That player has no bounty.");
            }
        }

        private void HandleList(IPlayer player)
        {
            if (bounties.Count == 0)
            {
                player.Reply("<color=gray>No bounties have been placed yet.</color>");
                return;
            }

            player.Reply("<color=orange>Active Bounties:</color>");
            foreach (var bounty in bounties.Values)
            {
                player.Reply($"<color=yellow>{bounty.TargetName}</color>: <color=orange>{bounty.RewardAmount} scrap</color>");
            }
        }

        void OnPlayerDeath(BasePlayer victim, HitInfo info)
        {
            if (victim == null || info?.InitiatorPlayer == null) return;

            var killer = info.InitiatorPlayer;

            if (bounties.TryGetValue(victim.UserIDString, out var bounty))
            {
                bounties.Remove(victim.UserIDString);

                if (victim == killer)
                {
                    pendingRewards[killer.UserIDString] = bounty.RewardAmount;
                    killer.ChatMessage($"You will receive {bounty.RewardAmount} scrap in 10 seconds.");
                }
                else
                {
                    var itemDef = ItemManager.FindItemDefinition(config.RewardItemShortname);
                    if (itemDef != null)
                    {
                        killer.inventory.GiveItem(ItemManager.Create(itemDef, bounty.RewardAmount));
                        killer.ChatMessage($"You claimed the bounty on {victim.displayName} and received {bounty.RewardAmount} scrap!");
                    }
                }

                SendDiscordEmbed("🟢 Bounty Claimed", $"**{killer.displayName}** claimed the bounty on **{victim.displayName}** for **{bounty.RewardAmount} scrap**.", "00FF00");
            }
        }

        void OnPlayerRespawned(BasePlayer player)
        {
            if (pendingRewards.TryGetValue(player.UserIDString, out int reward))
            {
                pendingRewards.Remove(player.UserIDString);

                timer.Once(10f, () =>
                {
                    var itemDef = ItemManager.FindItemDefinition(config.RewardItemShortname);
                    if (itemDef != null)
                    {
                        player.inventory.GiveItem(ItemManager.Create(itemDef, reward));
                        player.ChatMessage($"You received your bounty reward of {reward} scrap.");
                    }
                });
            }
        }

        private void SendDiscordEmbed(string title, string description, string color)
        {
            if (string.IsNullOrEmpty(config.WebhookUrl)) return;

            var payload = new
            {
                embeds = new[]
                {
                    new
                    {
                        title = title,
                        description = description,
                        color = Convert.ToInt32(color, 16)
                    }
                }
            };

            var json = JsonConvert.SerializeObject(payload);
            webrequest.Enqueue(config.WebhookUrl, json, (code, response) =>
            {
                if (code != 204)
                    PrintWarning($"Failed to send Discord webhook: {code} - {response}");
            }, this, RequestMethod.POST, new Dictionary<string, string> { ["Content-Type"] = "application/json" });
        }
    }
}

import http.server
import socketserver
import json
import os
import subprocess
import sys
from urllib.parse import urlparse
import time
import psutil
import shutil
import datetime

PORT = 8080
# Base directory for server instances. The current server will operate from here.
BASE_SERVER_DIR = 'arma_reforger_server'
# The following paths are relative to the script's root directory for portability.
CONFIG_PATH = os.path.join(BASE_SERVER_DIR, 'configs', 'config.json')
ADMIN_TOOLS_CONFIG_PATH = os.path.join(BASE_SERVER_DIR, 'profile', 'profile', 'ServerAdminTools_Config.json')
BACKUPS_DIR = 'backups'
server_process = None

def _stop_arma_server():
    """
    Helper function to gracefully and forcefully stop the Arma Reforger server process
    and its parent cmd.exe process if it's running.
    Returns a status message.
    """
    global server_process

    if server_process is None or server_process.poll() is not None:
        return "Server is not running."

    print(f"Attempting to stop server launched by cmd.exe PID: {server_process.pid}")

    try:
        arma_pid_found = None
        try:
            parent_p = psutil.Process(server_process.pid)
            for child in parent_p.children(recursive=True):
                if "ArmaReforgerServer.exe" in child.name():
                    arma_pid_found = child.pid
                    print(f"Found ArmaReforgerServer.exe with PID: {arma_pid_found}")
                    break
        except psutil.NoSuchProcess:
            print(f"Parent cmd.exe process (PID {server_process.pid}) not found, might have exited.")
            return "Parent process already gone."

        if arma_pid_found:
            print(f"Executing taskkill /F /T /PID {arma_pid_found}")
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(arma_pid_found)], check=True, shell=True)
            print("Arma Reforger server and its process tree killed successfully via taskkill.")
            return "Server stopped successfully."
        else:
            print("ArmaReforgerServer.exe not found. Attempting to terminate parent cmd.exe.")
            server_process.terminate()
            server_process.wait(timeout=10)
            print("Parent cmd.exe terminated gracefully.")
            return "Server terminated gracefully."

    except subprocess.TimeoutExpired:
        print("Termination timeout. Attempting to kill parent cmd.exe forcefully.")
        server_process.kill()
        server_process.wait()
        print("Parent cmd.exe forcibly killed.")
        return "Server forcibly killed after timeout."
    except psutil.NoSuchProcess:
        print("Process already gone, or never existed for stopping.")
        return "Server process was not found or was already stopped."
    except subprocess.CalledProcessError as e:
        print(f"Error during taskkill or subprocess.run: {e}")
        return f"Error stopping server: {e}"
    finally:
        server_process = None

def _create_new_server_folder():
    """
    Creates a new server folder by copying the contents of the base server directory.
    The new folder will be named 'arma_reforger_server_copy_X' where X is an incrementing number.
    Returns the path to the new server folder or raises an exception on failure.
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    source_dir = os.path.join(script_dir, BASE_SERVER_DIR)

    if not os.path.exists(source_dir):
        raise FileNotFoundError(f"Base server directory not found: {source_dir}")

    copy_num = 1
    while True:
        new_server_dir_name = f"{BASE_SERVER_DIR}_copy_{copy_num}"
        new_server_path = os.path.join(script_dir, new_server_dir_name)
        if not os.path.exists(new_server_path):
            break
        copy_num += 1

    try:
        shutil.copytree(source_dir, new_server_path)
        print(f"Successfully created new server folder at: {new_server_path}")
        return new_server_path
    except Exception as e:
        raise Exception(f"Failed to create new server folder: {e}")

def get_performance_metrics():
    cpu_percent = psutil.cpu_percent(interval=0.5)
    memory = psutil.virtual_memory()
    memory_percent = memory.percent
    disk = psutil.disk_usage(os.path.abspath(BASE_SERVER_DIR).split(os.sep)[0] + os.sep)
    disk_percent = disk.percent
    net_io = psutil.net_io_counters()
    bytes_sent_mb = round(net_io.bytes_sent / (1024 * 1024), 2)
    bytes_recv_mb = round(net_io.bytes_recv / (1024 * 1024), 2)
    
    metrics = {
        "cpu_percent": cpu_percent,
        "memory_percent": memory_percent,
        "disk_percent": disk_percent,
        "bytes_sent_mb": bytes_sent_mb,
        "bytes_recv_mb": bytes_recv_mb,
    }
    return metrics

class MyHandler(http.server.SimpleHTTPRequestHandler):
    def translate_path(self, path):
        _path = super().translate_path(path)
        if path.startswith('/HTML/'):
            return os.path.join(os.getcwd(), 'HTML', path[len('/HTML/'):])
        return _path

    def do_GET(self):
        parsed_path = urlparse(self.path).path

        config_endpoints = {
            '/arma_reforger_server/configs/config.json': CONFIG_PATH,
            '/arma_reforger_server/profile/profile/ServerAdminTools_Config.json': ADMIN_TOOLS_CONFIG_PATH
        }

        if parsed_path in config_endpoints:
            config_path = config_endpoints[parsed_path]
            try:
                os.makedirs(os.path.dirname(config_path), exist_ok=True)
                if os.path.exists(config_path):
                    with open(config_path, 'r', encoding='utf-8') as f:
                        config_data = json.load(f)
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps(config_data).encode())
                else:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({}).encode())
            except json.JSONDecodeError:
                print(f"Warning: {config_path} exists but is not valid JSON. Returning empty config.")
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({}).encode())
            except Exception as e:
                self.send_error(500, f'Error reading config: {e}')
            return
        
        elif parsed_path == '/server-performance':
            try:
                metrics = get_performance_metrics()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(metrics).encode())
            except Exception as e:
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                error_msg = {'status': 'error', 'message': f'Failed to get performance metrics: {e}'}
                self.wfile.write(json.dumps(error_msg).encode())
            return
        
        elif parsed_path == '/list-backups':
            try:
                os.makedirs(BACKUPS_DIR, exist_ok=True)
                backups = []
                for filename in os.listdir(BACKUPS_DIR):
                    if filename.endswith('.tar.gz'):
                        try:
                            parts = filename.split('_')
                            name = '_'.join(parts[:-2])
                            timestamp = int(parts[-2])
                            
                            backups.append({
                                'name': name,
                                'timestamp': timestamp,
                                'filename': filename
                            })
                        except (ValueError, IndexError):
                            backups.append({
                                'name': filename,
                                'timestamp': 0,
                                'filename': filename
                            })

                backups.sort(key=lambda x: x['timestamp'], reverse=True)

                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(backups).encode())
            except Exception as e:
                self.send_error(500, f'Error listing backups: {e}')
            return

        elif parsed_path == '/server-status':
            global server_process
            is_running = server_process is not None and server_process.poll() is None
            status_payload = {
                'is_running': is_running,
                'pid': server_process.pid if is_running else None
            }
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(status_payload).encode())
            return

        if self.path == '/':
            self.send_response(302)
            self.send_header('Location', '/HTML/arma_config_editor.html')
            self.end_headers()
            return

        try:
            super().do_GET()
        except Exception as e:
            self.send_error(500, f'Error serving static file: {e}')

    def do_POST(self):
        global server_process
        parsed_path = urlparse(self.path).path

        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)

        try:
            if parsed_path == '/save-config':
                config = json.loads(body.decode())
                os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
                with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                    json.dump(config, f, indent=2)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'success', 'message': 'Config saved successfully.'}).encode())

            elif parsed_path == '/save-admin-tools-config':
                admin_tools_config = json.loads(body.decode())
                os.makedirs(os.path.dirname(ADMIN_TOOLS_CONFIG_PATH), exist_ok=True)
                with open(ADMIN_TOOLS_CONFIG_PATH, 'w', encoding='utf-8') as f:
                    json.dump(admin_tools_config, f, indent=2)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'success', 'message': 'Admin Tools config saved successfully.'}).encode())
                
            elif parsed_path == '/create-backup':
                data = json.loads(body.decode())
                name = data.get('name', 'config_backup').replace(' ', '_').strip()
                if not name:
                    name = 'config_backup'
                
                timestamp = int(time.time())
                backup_filename = f"{name}_{timestamp}.tar.gz"
                backup_path = os.path.join(BACKUPS_DIR, backup_filename)

                try:
                    os.makedirs(BACKUPS_DIR, exist_ok=True)
                    temp_dir = os.path.join(BACKUPS_DIR, f"temp_{timestamp}")
                    os.makedirs(temp_dir, exist_ok=True)
                    
                    if os.path.exists(CONFIG_PATH):
                        shutil.copy(CONFIG_PATH, os.path.join(temp_dir, 'config.json'))
                    else:
                        with open(os.path.join(temp_dir, 'config.json'), 'w') as f:
                            json.dump({}, f)

                    if os.path.exists(ADMIN_TOOLS_CONFIG_PATH):
                        shutil.copy(ADMIN_TOOLS_CONFIG_PATH, os.path.join(temp_dir, 'ServerAdminTools_Config.json'))
                    else:
                        with open(os.path.join(temp_dir, 'ServerAdminTools_Config.json'), 'w') as f:
                            json.dump({}, f)

                    shutil.make_archive(os.path.join(BACKUPS_DIR, f"{name}_{timestamp}"), 'gztar', root_dir=temp_dir)
                    shutil.rmtree(temp_dir)

                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'success', 'message': f'Backup "{backup_filename}" created successfully.'}).encode())
                except FileNotFoundError:
                    self.send_response(404)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'error', 'message': 'Original config files not found.'}).encode())
                except Exception as e:
                    self.send_response(500)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'error', 'message': f'Failed to create backup: {e}'}).encode())
                
            elif parsed_path == '/restore-backup':
                data = json.loads(body.decode())
                filename = data.get('filename')
                if not filename:
                    raise ValueError("Filename not provided.")

                backup_path = os.path.join(BACKUPS_DIR, filename)

                if not os.path.exists(backup_path):
                    self.send_response(404)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'error', 'message': 'Backup file not found.'}).encode())
                    return

                try:
                    temp_dir = os.path.join(BACKUPS_DIR, 'restore_temp')
                    os.makedirs(temp_dir, exist_ok=True)

                    shutil.unpack_archive(backup_path, temp_dir, 'gztar')

                    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
                    os.makedirs(os.path.dirname(ADMIN_TOOLS_CONFIG_PATH), exist_ok=True)

                    shutil.copy(os.path.join(temp_dir, 'config.json'), CONFIG_PATH)
                    shutil.copy(os.path.join(temp_dir, 'ServerAdminTools_Config.json'), ADMIN_TOOLS_CONFIG_PATH)

                    shutil.rmtree(temp_dir)

                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'success', 'message': f'Configuration restored from "{filename}".'}).encode())
                except Exception as e:
                    self.send_response(500)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'error', 'message': f'Failed to restore backup: {e}'}).encode())

            elif parsed_path == '/start-server':
                if server_process is not None and server_process.poll() is None:
                    response_payload = {'status': 'error', 'message': 'Server is already running.'}
                else:
                    # FIX: Explicitly check for and create config files if they don't exist
                    # This removes the hidden dependency on the 'create backup' function
                    # It's better to create them with empty content than to have the server fail
                    # to start because of a missing file.
                    
                    if not os.path.exists(CONFIG_PATH):
                        print(f"Warning: {CONFIG_PATH} not found. Creating empty file.")
                        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
                        with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                            json.dump({}, f)
                    
                    if not os.path.exists(ADMIN_TOOLS_CONFIG_PATH):
                        print(f"Warning: {ADMIN_TOOLS_CONFIG_PATH} not found. Creating empty file.")
                        os.makedirs(os.path.dirname(ADMIN_TOOLS_CONFIG_PATH), exist_ok=True)
                        with open(ADMIN_TOOLS_CONFIG_PATH, 'w', encoding='utf-8') as f:
                            json.dump({}, f)

                    # Now, proceed with the original logic to start the batch file
                    script_dir = os.path.dirname(os.path.abspath(__file__))
                    bat_path = os.path.join(script_dir, BASE_SERVER_DIR, 'start_server.bat')
                    
                    if not os.path.isfile(bat_path):
                        raise FileNotFoundError(f"Batch file not found: {bat_path}")

                    server_process = subprocess.Popen(
                        ['cmd.exe', '/c', bat_path],
                        shell=False
                    )
                    print(f"Server started (cmd.exe PID: {server_process.pid})")
                    response_payload = {'status': 'success', 'message': 'Server started successfully.', 'pid': server_process.pid}

                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response_payload).encode())

            elif parsed_path == '/stop-server':
                status_message = _stop_arma_server()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                response_payload = {'status': 'success', 'message': status_message}
                self.wfile.write(json.dumps(response_payload).encode())

            elif parsed_path == '/create-new-server':
                try:
                    new_folder_path = _create_new_server_folder()
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    response_payload = {'status': 'success', 'message': f'New server folder created at: {new_folder_path}'}
                    self.wfile.write(json.dumps(response_payload).encode())
                except Exception as e:
                    self.send_response(500)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    error_msg = {'status': 'error', 'message': str(e)}
                    self.wfile.write(json.dumps(error_msg).encode())

            else:
                self.send_error(404, 'Unknown path')

        except FileNotFoundError as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_msg = {'status': 'error', 'message': str(e)}
            self.wfile.write(json.dumps(error_msg).encode())
        except json.JSONDecodeError:
            self.send_response(400)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_msg = {'status': 'error', 'message': 'Invalid JSON body.'}
            self.wfile.write(json.dumps(error_msg).encode())
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_msg = {'status': 'error', 'message': f'Internal server error: {e}'}
            self.wfile.write(json.dumps(error_msg).encode())

    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    os.makedirs(os.path.dirname(ADMIN_TOOLS_CONFIG_PATH), exist_ok=True)
    os.makedirs('HTML', exist_ok=True)
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    
    # FIX: Ensure config files exist at startup to prevent dependencies
    # This is the core fix for the "unclickable button" problem.
    if not os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
            json.dump({}, f, indent=2)
            
    if not os.path.exists(ADMIN_TOOLS_CONFIG_PATH):
        with open(ADMIN_TOOLS_CONFIG_PATH, 'w', encoding='utf-8') as f:
            json.dump({}, f, indent=2)

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), MyHandler) as httpd:
        print(f"Serving at http://localhost:{PORT}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Server stopped by user (Ctrl+C)")
        finally:
            print("Web server shutting down, attempting to stop Arma Reforger server...")
            stop_message = _stop_arma_server()
            print(stop_message)
            print("Web server shut down.")
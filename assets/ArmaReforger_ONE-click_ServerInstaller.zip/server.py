import http.server
import socketserver
import json
import os
import subprocess
import signal
import sys
from urllib.parse import urlparse
import time
import psutil # Ensure this is installed!

PORT = 8080
CONFIG_PATH = os.path.join('arma_reforger_server', 'configs', 'config.json')
server_process = None # Global variable to hold the Popen object (for cmd.exe)

class MyHandler(http.server.SimpleHTTPRequestHandler):
    # Override translate_path to correctly serve files from the 'HTML' subfolder
    def translate_path(self, path):
        # Default behavior: translate / to current directory.
        _path = super().translate_path(path)
        
        # If the requested URL path starts with /HTML/, then we should look for the file
        # inside the actual 'HTML' directory on the file system.
        if path.startswith('/HTML/'):
            # Remove the /HTML/ prefix from the URL path and prepend the actual 'HTML' directory path
            # Example: /HTML/arma_config_editor.html -> <current_dir>/HTML/arma_config_editor.html
            return os.path.join(os.getcwd(), 'HTML', path[len('/HTML/'):])
        
        # For other paths (like /, or /arma_reforger_server/configs/config.json),
        # let the original translate_path handle it.
        return _path

    def do_GET(self):
        # 1. Handle requests for the config.json API endpoint FIRST
        if self.path == '/arma_reforger_server/configs/config.json':
            try:
                os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
                if os.path.exists(CONFIG_PATH):
                    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                        config_data = json.load(f)
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps(config_data).encode())
                else:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({}).encode())
            except json.JSONDecodeError:
                print(f"Warning: {CONFIG_PATH} exists but is not valid JSON. Returning empty config.")
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({}).encode())
            except Exception as e:
                self.send_error(500, f'Error reading config: {e}')
            return # Crucial: Return after handling this specific path

        # 2. Handle the root path (/) by redirecting to your main HTML file in the HTML subfolder
        if self.path == '/':
            self.send_response(302) # HTTP 302 Found (redirect)
            self.send_header('Location', '/HTML/arma_config_editor.html') # Redirect to your specific HTML file
            self.end_headers()
            return # Crucial: Return after sending redirect

        # 3. For all other GET requests (including those for files inside /HTML/),
        # let the default SimpleHTTPRequestHandler handle it.
        # It will now use our overridden translate_path to find files in the 'HTML' folder.
        try:
            super().do_GET() 
        except Exception as e:
            # Catch general errors during static file serving
            self.send_error(500, f'Error serving static file: {e}')
            
    def do_POST(self):
        global server_process
        parsed_path = urlparse(self.path).path

        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)

        try:
            if parsed_path == '/save-config':
                config = json.loads(body.decode())
                os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
                with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                    json.dump(config, f, indent=2)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'Config saved successfully.')

            elif parsed_path == '/start-server':
                if server_process is not None and server_process.poll() is None:
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b'Server already running.')
                    return

                script_dir = os.path.dirname(os.path.abspath(__file__))
                bat_path = os.path.join(script_dir, 'arma_reforger_server', 'start_server.bat')

                if not os.path.isfile(bat_path):
                    raise FileNotFoundError(f"Batch file not found: {bat_path}")

                server_process = subprocess.Popen(
                    ['cmd.exe', '/c', bat_path],
                    shell=False
                )
                print(f"Server started (cmd.exe PID: {server_process.pid})")
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'Server started.')

            elif parsed_path == '/stop-server':
                if server_process is not None and server_process.poll() is None:
                    print(f"Attempting to stop server launched by cmd.exe PID: {server_process.pid}")
                    try:
                        arma_pid_found = None
                        try:
                            # Search for ArmaReforgerServer.exe within the process tree of the cmd.exe
                            parent_p = psutil.Process(server_process.pid)
                            for child in parent_p.children(recursive=True): # Check children recursively
                                if "ArmaReforgerServer.exe" in child.name():
                                    arma_pid_found = child.pid
                                    print(f"Found ArmaReforgerServer.exe with PID: {arma_pid_found}")
                                    break
                        except psutil.NoSuchProcess:
                            print(f"Parent cmd.exe process (PID {server_process.pid}) not found, might have exited.")

                        if arma_pid_found:
                            # Use taskkill to kill the Arma process tree forcefully
                            print(f"Executing taskkill /F /T /PID {arma_pid_found}")
                            subprocess.run(['taskkill', '/F', '/T', '/PID', str(arma_pid_found)], check=True, shell=True)
                            print("Arma Reforger server and its process tree killed successfully via taskkill.")
                        else:
                            # Fallback if Arma process not found, try to terminate the original cmd.exe
                            print("ArmaReforgerServer.exe not found. Attempting to terminate parent cmd.exe.")
                            server_process.terminate() # Send SIGTERM (Windows equivalent)
                            server_process.wait(timeout=10) # Give it time to exit
                            print("Parent cmd.exe terminated gracefully.")

                    except subprocess.TimeoutExpired:
                        print("Termination timeout. Attempting to kill parent cmd.exe forcefully.")
                        server_process.kill() # Forcefully kill (SIGKILL)
                        server_process.wait() # Wait until it's actually dead
                        print("Parent cmd.exe forcibly killed.")
                    except psutil.NoSuchProcess:
                        print("Process already gone, or never existed for stopping.")
                    except subprocess.CalledProcessError as e:
                        print(f"Error during taskkill or subprocess.run: {e}")
                    finally:
                        server_process = None # Clear the global variable regardless
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b'Server stop attempt initiated.')
                else:
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b'Server not running.')

            else:
                self.send_error(404, 'Unknown path')

        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.end_headers()
            error_msg = f'Error handling {parsed_path}: {e}'
            self.wfile.write(error_msg.encode())

    # Optional: silence default http.server logging if you only want your print statements
    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), MyHandler) as httpd:
        print(f"Serving at http://localhost:{PORT}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Server stopped by user (Ctrl+C)")
        finally:
            # Ensure the Arma Reforger server is stopped when the Python web server exits
            if server_process and server_process.poll() is None:
                print("Web server shutting down, attempting to stop Arma Reforger server...")
                try:
                    arma_pid_on_exit = None
                    try:
                        parent_p_exit = psutil.Process(server_process.pid)
                        for child in parent_p_exit.children(recursive=True):
                            if "ArmaReforgerServer.exe" in child.name():
                                arma_pid_on_exit = child.pid
                                break
                    except psutil.NoSuchProcess:
                        pass # Parent cmd.exe might already be gone

                    if arma_pid_on_exit:
                        print(f"Executing taskkill /F /T /PID {arma_pid_on_exit} during web server shutdown.")
                        subprocess.run(['taskkill', '/F', '/T', '/PID', str(arma_pid_on_exit)], shell=True)
                        print("Arma Reforger server killed during web server shutdown.")
                    else:
                        print("ArmaReforgerServer.exe not found during shutdown. Terminating parent cmd.exe.")
                        server_process.terminate()
                        server_process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    print("Parent cmd.exe did not terminate during shutdown, attempting to kill.")
                    server_process.kill()
                    server_process.wait()
                except Exception as e:
                    print(f"Error during final shutdown cleanup: {e}")
                finally:
                    # Ensure process handle is released even if it was just cmd.exe
                    if server_process and server_process.poll() is None:
                        server_process.kill() # Final fallback just in case
                    server_process = None
            print("Web server shut down.")
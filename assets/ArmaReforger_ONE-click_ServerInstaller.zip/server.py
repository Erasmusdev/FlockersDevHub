import http.server
import socketserver
import json
import os
import subprocess
import sys
from urllib.parse import urlparse
import time
import psutil # Ensure this is installed!
import shutil # Added for file operations

PORT = 8080
# Base directory for server instances. The current server will operate from here.
BASE_SERVER_DIR = 'arma_reforger_server'
CONFIG_PATH = os.path.join(BASE_SERVER_DIR, 'configs', 'config.json')
# Corrected ADMIN_TOOLS_CONFIG_PATH to match the path used in the HTML/JS
ADMIN_TOOLS_CONFIG_PATH = os.path.join(BASE_SERVER_DIR, 'profile', 'profile', 'ServerAdminTools_Config.json')
server_process = None # Global variable to hold the Popen object (for cmd.exe)

def _stop_arma_server():
    """
    Helper function to gracefully and forcefully stop the Arma Reforger server process
    and its parent cmd.exe process if it's running.
    Returns a status message.
    """
    global server_process

    if server_process is None or server_process.poll() is not None:
        return "Server is not running."

    print(f"Attempting to stop server launched by cmd.exe PID: {server_process.pid}")

    try:
        # Search for ArmaReforgerServer.exe within the process tree of the cmd.exe
        arma_pid_found = None
        try:
            parent_p = psutil.Process(server_process.pid)
            # Check children recursively for the main Arma process
            for child in parent_p.children(recursive=True):
                if "ArmaReforgerServer.exe" in child.name():
                    arma_pid_found = child.pid
                    print(f"Found ArmaReforgerServer.exe with PID: {arma_pid_found}")
                    break
        except psutil.NoSuchProcess:
            print(f"Parent cmd.exe process (PID {server_process.pid}) not found, might have exited.")
            # If parent is gone, the child (Arma server) is likely also gone or orphaned.
            return "Parent process already gone."

        if arma_pid_found:
            # Use taskkill to kill the Arma process tree forcefully
            print(f"Executing taskkill /F /T /PID {arma_pid_found}")
            # Note: We use shell=True here for taskkill as it's a built-in shell command, but pass arguments separately for safety
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(arma_pid_found)], check=True, shell=True)
            print("Arma Reforger server and its process tree killed successfully via taskkill.")
            return "Server stopped successfully."
        else:
            # Fallback if Arma process not found, try to terminate the original cmd.exe
            print("ArmaReforgerServer.exe not found. Attempting to terminate parent cmd.exe.")
            server_process.terminate() # Send SIGTERM (Windows equivalent)
            server_process.wait(timeout=10) # Give it time to exit
            print("Parent cmd.exe terminated gracefully.")
            return "Server terminated gracefully."

    except subprocess.TimeoutExpired:
        print("Termination timeout. Attempting to kill parent cmd.exe forcefully.")
        server_process.kill() # Forcefully kill (SIGKILL)
        server_process.wait() # Wait until it's actually dead
        print("Parent cmd.exe forcibly killed.")
        return "Server forcibly killed after timeout."
    except psutil.NoSuchProcess:
        print("Process already gone, or never existed for stopping.")
        return "Server process was not found or was already stopped."
    except subprocess.CalledProcessError as e:
        print(f"Error during taskkill or subprocess.run: {e}")
        return f"Error stopping server: {e}"
    finally:
        server_process = None # Clear the global variable regardless

def _create_new_server_folder():
    """
    Creates a new server folder by copying the contents of the base server directory.
    The new folder will be named 'arma_reforger_server_copy_X' where X is an incrementing number.
    Returns the path to the new server folder or raises an exception on failure.
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    source_dir = os.path.join(script_dir, BASE_SERVER_DIR)

    if not os.path.exists(source_dir):
        raise FileNotFoundError(f"Base server directory not found: {source_dir}")

    # Find the next available copy number
    copy_num = 1
    while True:
        new_server_dir_name = f"{BASE_SERVER_DIR}_copy_{copy_num}"
        new_server_path = os.path.join(script_dir, new_server_dir_name)
        if not os.path.exists(new_server_path):
            break
        copy_num += 1

    try:
        # Copy the entire directory
        shutil.copytree(source_dir, new_server_path)
        print(f"Successfully created new server folder at: {new_server_path}")
        return new_server_path
    except Exception as e:
        raise Exception(f"Failed to create new server folder: {e}")

class MyHandler(http.server.SimpleHTTPRequestHandler):
    # Override translate_path to correctly serve files from the 'HTML' subfolder
    def translate_path(self, path):
        # Default behavior: translate / to current directory.
        _path = super().translate_path(path)

        # If the requested URL path starts with /HTML/, then we should look for the file
        # inside the actual 'HTML' directory on the file system.
        if path.startswith('/HTML/'):
            # Example: /HTML/arma_config_editor.html -> <current_dir>/HTML/arma_config_editor.html
            return os.path.join(os.getcwd(), 'HTML', path[len('/HTML/'):])

        # For other paths (like /, or /arma_reforger_server/configs/config.json),
        # let the original translate_path handle it.
        return _path

    def do_GET(self):
        parsed_path = urlparse(self.path).path

        # 1. Handle API endpoints for various config files
        config_endpoints = {
            '/arma_reforger_server/configs/config.json': CONFIG_PATH,
            '/arma_reforger_server/profile/profile/ServerAdminTools_Config.json': ADMIN_TOOLS_CONFIG_PATH # Corrected path
        }

        if parsed_path in config_endpoints:
            config_path = config_endpoints[parsed_path]
            try:
                # Ensure parent directories exist before trying to open/create the file
                os.makedirs(os.path.dirname(config_path), exist_ok=True)
                if os.path.exists(config_path):
                    with open(config_path, 'r', encoding='utf-8') as f:
                        config_data = json.load(f)
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps(config_data).encode())
                else:
                    # If config file doesn't exist, return an empty JSON object
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({}).encode())
            except json.JSONDecodeError:
                print(f"Warning: {config_path} exists but is not valid JSON. Returning empty config.")
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({}).encode())
            except Exception as e:
                self.send_error(500, f'Error reading config: {e}')
            return

        elif parsed_path == '/server-status':
            global server_process
            is_running = server_process is not None and server_process.poll() is None
            status_payload = {
                'is_running': is_running,
                'pid': server_process.pid if is_running else None
            }
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(status_payload).encode())
            return

        # 2. Handle the root path (/) by redirecting to your main HTML file in the HTML subfolder
        if self.path == '/':
            self.send_response(302) # HTTP 302 Found (redirect)
            self.send_header('Location', '/HTML/arma_config_editor.html') # Redirect to your specific HTML file
            self.end_headers()
            return

        # 3. For all other GET requests (including those for files inside /HTML/),
        # let the default SimpleHTTPRequestHandler handle it.
        try:
            super().do_GET()
        except Exception as e:
            # Catch general errors during static file serving
            self.send_error(500, f'Error serving static file: {e}')

    def do_POST(self):
        global server_process
        parsed_path = urlparse(self.path).path

        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)

        try:
            if parsed_path == '/save-config':
                config = json.loads(body.decode())
                os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
                with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                    json.dump(config, f, indent=2)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'success', 'message': 'Config saved successfully.'}).encode())

            elif parsed_path == '/save-admin-tools-config':
                admin_tools_config = json.loads(body.decode())
                os.makedirs(os.path.dirname(ADMIN_TOOLS_CONFIG_PATH), exist_ok=True)
                with open(ADMIN_TOOLS_CONFIG_PATH, 'w', encoding='utf-8') as f:
                    json.dump(admin_tools_config, f, indent=2)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'success', 'message': 'Admin Tools config saved successfully.'}).encode())

            elif parsed_path == '/start-server':
                if server_process is not None and server_process.poll() is None:
                    response_payload = {'status': 'error', 'message': 'Server is already running.'}
                else:
                    script_dir = os.path.dirname(os.path.abspath(__file__))
                    bat_path = os.path.join(script_dir, BASE_SERVER_DIR, 'start_server.bat') # Use BASE_SERVER_DIR

                    if not os.path.isfile(bat_path):
                        raise FileNotFoundError(f"Batch file not found: {bat_path}")

                    server_process = subprocess.Popen(
                        ['cmd.exe', '/c', bat_path],
                        shell=False
                    )
                    print(f"Server started (cmd.exe PID: {server_process.pid})")
                    response_payload = {'status': 'success', 'message': 'Server started successfully.', 'pid': server_process.pid}

                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response_payload).encode())

            elif parsed_path == '/stop-server':
                status_message = _stop_arma_server()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                # Create a simple JSON response for the front-end
                response_payload = {'status': 'success', 'message': status_message}
                self.wfile.write(json.dumps(response_payload).encode())

            elif parsed_path == '/create-new-server':
                try:
                    new_folder_path = _create_new_server_folder()
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    response_payload = {'status': 'success', 'message': f'New server folder created at: {new_folder_path}'}
                    self.wfile.write(json.dumps(response_payload).encode())
                except Exception as e:
                    self.send_response(500)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    error_msg = {'status': 'error', 'message': str(e)}
                    self.wfile.write(json.dumps(error_msg).encode())

            else:
                self.send_error(404, 'Unknown path')

        except FileNotFoundError as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_msg = {'status': 'error', 'message': str(e)}
            self.wfile.write(json.dumps(error_msg).encode())
        except json.JSONDecodeError:
            self.send_response(400)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_msg = {'status': 'error', 'message': 'Invalid JSON body.'}
            self.wfile.write(json.dumps(error_msg).encode())
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            error_msg = {'status': 'error', 'message': f'Internal server error: {e}'}
            self.wfile.write(json.dumps(error_msg).encode())

    # Optional: silence default http.server logging if you only want your print statements
    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    # Ensure base server directory and config paths exist for initial setup
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    os.makedirs(os.path.dirname(ADMIN_TOOLS_CONFIG_PATH), exist_ok=True)
    # Ensure the HTML directory exists
    os.makedirs('HTML', exist_ok=True)


    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), MyHandler) as httpd:
        print(f"Serving at http://localhost:{PORT}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Server stopped by user (Ctrl+C)")
        finally:
            # Ensure the Arma Reforger server is stopped when the Python web server exits
            print("Web server shutting down, attempting to stop Arma Reforger server...")
            stop_message = _stop_arma_server()
            print(stop_message)
            print("Web server shut down.")
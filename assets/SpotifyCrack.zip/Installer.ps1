#############################################################################
#                                                                           #
#   Spotify Ad Blocker Installer v1.1                                       #
#   Copyright Flockers Design                                               #
#                                                                           #
#   Description: Automated installer for Spotify with BlockTheSpot patch    #
#   v1.1: Includes cleanup for old scheduled tasks.                        #
#                                                                           #
#############################################################################

# 1. CLEANUP OLD SCHEDULED TASKS
Write-Host "---"
$OldTaskName = "Spotify BlockTheSpot Auto-Update"
$TaskExists = Get-ScheduledTask -TaskName $OldTaskName -ErrorAction SilentlyContinue

if ($TaskExists) {
    Write-Host "Old scheduled task found. Removing '$OldTaskName'..." -ForegroundColor Yellow
    Unregister-ScheduledTask -TaskName $OldTaskName -Confirm:$false
    Write-Host "✅ Old task removed." -ForegroundColor Green
} else {
    Write-Host "No old scheduled tasks found." -ForegroundColor Gray
}

# 2. CLOSE SPOTIFY PROCESSES
Write-Host "---"
Write-Host "Checking for running Spotify processes..." -ForegroundColor Yellow

$SpotifyProcesses = Get-Process -Name "Spotify" -ErrorAction SilentlyContinue
if ($SpotifyProcesses) {
    Write-Host "Closing Spotify..." -ForegroundColor Yellow
    $SpotifyProcesses | Stop-Process -Force
    Start-Sleep -Seconds 2
    Write-Host "✅ Spotify processes closed." -ForegroundColor Green
}

# 3. DOWNLOAD AND INSTALL COMPATIBLE SPOTIFY VERSION
Write-Host "---"
Write-Host "Downloading compatible Spotify version (1.2.77.358)..." -ForegroundColor Yellow

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$SpotifySetup = "$env:TEMP\spotify-1-2-77-358-g4339a634.exe"
$MediaFirePage = "https://www.mediafire.com/file/4mj2hlgvhk8wlxv/spotify-1-2-77-358-g4339a634.exe/file"

try {
    Write-Host "Fetching download link..." -ForegroundColor Gray
    if (Test-Path $SpotifySetup) { Remove-Item $SpotifySetup -Force -ErrorAction SilentlyContinue }
    
    $PageContent = Invoke-WebRequest -Uri $MediaFirePage -UseBasicParsing -TimeoutSec 30
    if ($PageContent.Content -match 'href="(https://download\d+\.mediafire\.com/[^"]+)"') {
        $SpotifyUrl = $matches[1]
    } else {
        throw "Could not find download link."
    }
    
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $SpotifyUrl -OutFile $SpotifySetup -UseBasicParsing -TimeoutSec 300
    $ProgressPreference = 'Continue'
    
    Write-Host "✅ Spotify installer downloaded." -ForegroundColor Green
    Write-Host "Installing Spotify..." -ForegroundColor Yellow
    Start-Process -FilePath $SpotifySetup -ArgumentList "/silent" -Wait
    Write-Host "✅ Spotify installed successfully." -ForegroundColor Green
    Remove-Item $SpotifySetup -Force -ErrorAction SilentlyContinue
} catch {
    Write-Host "❌ Failed: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..." -ForegroundColor Cyan
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

Start-Sleep -Seconds 3
Get-Process -Name "Spotify" -ErrorAction SilentlyContinue | Stop-Process -Force

# 4. CLEAR SPOTIFY CACHE
Write-Host "---"
Write-Host "Clearing Spotify cache..." -ForegroundColor Yellow
$SpotifyStoragePath = "$env:APPDATA\Spotify\Storage"
if (Test-Path $SpotifyStoragePath) {
    Remove-Item -Path $SpotifyStoragePath -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "✅ Cache cleared." -ForegroundColor Green
}

# 5. APPLY BLOCKTHESPOT PATCH
Write-Host "---"
Write-Host "Applying BlockTheSpot patch..." -ForegroundColor Yellow
$SpotifyPath = "$env:APPDATA\Spotify"
$DllSourcePath = "$PSScriptRoot\DLL's"

if (Test-Path $DllSourcePath) {
    try {
        Copy-Item -Path "$DllSourcePath\dpapi.dll" -Destination "$SpotifyPath\dpapi.dll" -Force
        Copy-Item -Path "$DllSourcePath\config.ini" -Destination "$SpotifyPath\config.ini" -Force
        Write-Host "✨ Patch applied successfully!" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed to copy patch files." -ForegroundColor Red
    }
} else {
    Write-Host "❌ Error: DLL's folder not found." -ForegroundColor Red
}

Write-Host "---"
Write-Host "✅ SETUP COMPLETE!" -ForegroundColor Green
Write-Host "Press any key to close..." -ForegroundColor Cyan
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#############################################################################
#                                                                           #
#   Spotify Ad Blocker Installer v1.0                                      #
#   Copyright Flockers Design                                               #
#                                                                           #
#   Description: Automated installer for Spotify with BlockTheSpot patch   #
#   This script installs a compatible version of Spotify (1.2.77.358)      #
#   and applies the BlockTheSpot ad-blocking patch automatically.          #
#                                                                           #
#   Support: https://github.com/Erasmusdev                                 #
#                                                                           #
#############################################################################

# Note: We don't run as admin because Spotify installer requires a normal user account

# 1. CLOSE SPOTIFY PROCESSES

Write-Host "---"
Write-Host "Checking for running Spotify processes..." -ForegroundColor Yellow

$SpotifyProcesses = Get-Process -Name "Spotify" -ErrorAction SilentlyContinue
if ($SpotifyProcesses) {
    Write-Host "Closing Spotify..." -ForegroundColor Yellow
    $SpotifyProcesses | Stop-Process -Force
    Start-Sleep -Seconds 2
    Write-Host "✅ Spotify processes closed." -ForegroundColor Green
} else {
    Write-Host "No Spotify processes running." -ForegroundColor Gray
}

# 2. DOWNLOAD AND INSTALL COMPATIBLE SPOTIFY VERSION

Write-Host "---"
Write-Host "Downloading compatible Spotify version (1.2.77.358)..." -ForegroundColor Yellow

# Ensure TLS 1.2 is used for secure connection
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$SpotifySetup = "$env:TEMP\spotify-1-2-77-358-g4339a634.exe"
$SpotifyUrl = "https://download1335.mediafire.com/qguqph196gugq4X9xBYlw80OaL0DNUE-VwboPOkqiEW_QsLsdcFxBXliRRjiE_7IZXaxsMmnTCXPye5VfNo31ic6S3T5Pzi4kN2Q3Qax36BlbAjKtUDMDiTouLV02ry0IWSIN2ctRDhtwDACJtLcVWrP_lW-j7Wb2jDTPKgycgmQ/4mj2hlgvhk8wlxv/spotify-1-2-77-358-g4339a634.exe"

try {
    Write-Host "Downloading Spotify installer (119 MB, please wait)..." -ForegroundColor Gray
    Invoke-WebRequest -Uri $SpotifyUrl -OutFile $SpotifySetup -UseBasicParsing
    Write-Host "✅ Spotify installer downloaded." -ForegroundColor Green
    
    Write-Host "Installing/Updating Spotify..." -ForegroundColor Yellow
    Start-Process -FilePath $SpotifySetup -ArgumentList "/silent" -Wait
    Write-Host "✅ Spotify installed/updated successfully." -ForegroundColor Green
    
    # Clean up installer
    Remove-Item $SpotifySetup -Force -ErrorAction SilentlyContinue
} catch {
    Write-Host "❌ Failed to download/install Spotify." -ForegroundColor Red
    Write-Host "Error details: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..." -ForegroundColor Cyan
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

# Wait for Spotify to finish installing
Start-Sleep -Seconds 3

# Close Spotify if it auto-started after installation
Get-Process -Name "Spotify" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

# 3. CLEAR SPOTIFY CACHE (Fix black screen issue)

Write-Host "---"
Write-Host "Clearing Spotify cache to prevent black screen issue..." -ForegroundColor Yellow

$SpotifyStoragePath = "$env:APPDATA\Spotify\Storage"
if (Test-Path $SpotifyStoragePath) {
    try {
        Remove-Item -Path $SpotifyStoragePath -Recurse -Force -ErrorAction Stop
        Write-Host "✅ Spotify cache cleared successfully." -ForegroundColor Green
    } catch {
        Write-Host "⚠️  Could not clear cache." -ForegroundColor Yellow
    }
} else {
    Write-Host "No cache found to clear." -ForegroundColor Gray
}

# 4. APPLY BLOCKTHESPOT PATCH

Write-Host "---"
Write-Host "Applying BlockTheSpot patch..." -ForegroundColor Yellow

$SpotifyPath = "$env:APPDATA\Spotify"
$DllSourcePath = "$PSScriptRoot\DLL's"

# Check if DLL folder exists
if (-not (Test-Path $DllSourcePath)) {
    Write-Host "❌ Error: DLL's folder not found at: $DllSourcePath" -ForegroundColor Red
    Write-Host "Please ensure dpapi.dll and config.ini are in the DLL's folder." -ForegroundColor Red
    Write-Host "Press any key to exit..." -ForegroundColor Cyan
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

# Check if required files exist
$DpapiDll = "$DllSourcePath\dpapi.dll"
$ConfigIni = "$DllSourcePath\config.ini"

if (-not (Test-Path $DpapiDll)) {
    Write-Host "❌ Error: dpapi.dll not found in DLL's folder." -ForegroundColor Red
    Write-Host "Press any key to exit..." -ForegroundColor Cyan
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

if (-not (Test-Path $ConfigIni)) {
    Write-Host "❌ Error: config.ini not found in DLL's folder." -ForegroundColor Red
    Write-Host "Press any key to exit..." -ForegroundColor Cyan
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

# Copy files to Spotify directory
try {
    Copy-Item -Path $DpapiDll -Destination "$SpotifyPath\dpapi.dll" -Force
    Write-Host "✅ dpapi.dll copied successfully." -ForegroundColor Green
    
    Copy-Item -Path $ConfigIni -Destination "$SpotifyPath\config.ini" -Force
    Write-Host "✅ config.ini copied successfully." -ForegroundColor Green
    
    Write-Host ""
    Write-Host "✨ BlockTheSpot patch applied successfully!" -ForegroundColor Green
    Write-Host "✨ You can now open Spotify and enjoy ad-free music!" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed to copy patch files." -ForegroundColor Red
    Write-Host "Error details: $_" -ForegroundColor Red
}

Write-Host "---"

# 5. SCHEDULED TASK SETUP

## Define Variables
$TaskName = "Spotify BlockTheSpot Auto-Update"
$TaskPath = "C:\Scripts"
$TaskFile = "$TaskPath\SpotifyBlockTheSpotFix.ps1"
$ScheduleTime = "10:00 AM" # Change this time if you prefer

## The Core Update/Fix Script Content (For the scheduled task)
$ScriptContent = @"
# Close Spotify if running
Get-Process -Name 'Spotify' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

# Download and install compatible Spotify version (1.2.77.358)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
`$SpotifySetup = "`$env:TEMP\spotify-1-2-77-358-g4339a634.exe"
`$SpotifyUrl = 'https://download1335.mediafire.com/qguqph196gugq4X9xBYlw80OaL0DNUE-VwboPOkqiEW_QsLsdcFxBXliRRjiE_7IZXaxsMmnTCXPye5VfNo31ic6S3T5Pzi4kN2Q3Qax36BlbAjKtUDMDiTouLV02ry0IWSIN2ctRDhtwDACJtLcVWrP_lW-j7Wb2jDTPKgycgmQ/4mj2hlgvhk8wlxv/spotify-1-2-77-358-g4339a634.exe'
Invoke-WebRequest -Uri `$SpotifyUrl -OutFile `$SpotifySetup -UseBasicParsing
Start-Process -FilePath `$SpotifySetup -ArgumentList '/silent' -Wait
Remove-Item `$SpotifySetup -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 3
Get-Process -Name 'Spotify' -ErrorAction SilentlyContinue | Stop-Process -Force

# Clear cache to prevent black screen
`$CachePath = "`$env:APPDATA\Spotify\Storage"
if (Test-Path `$CachePath) { Remove-Item -Path `$CachePath -Recurse -Force -ErrorAction SilentlyContinue }

# Copy BlockTheSpot files from DLL folder
`$DllPath = "$PSScriptRoot\DLL's"
`$SpotifyPath = "`$env:APPDATA\Spotify"
if (Test-Path "`$DllPath\dpapi.dll") { Copy-Item -Path "`$DllPath\dpapi.dll" -Destination "`$SpotifyPath\dpapi.dll" -Force }
if (Test-Path "`$DllPath\config.ini") { Copy-Item -Path "`$DllPath\config.ini" -Destination "`$SpotifyPath\config.ini" -Force }
"@

## Create the Directory and Write the Fix Script
try {
    If (-not (Test-Path $TaskPath)) {
        Write-Host "Creating directory: $TaskPath"
        New-Item -Path $TaskPath -ItemType Directory -Force | Out-Null
    }
    Write-Host "Writing core update script to: $TaskFile"
    $ScriptContent | Out-File $TaskFile -Encoding UTF8

    ## Define Scheduled Task Components (run as regular user, not admin)
    $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""$TaskFile"""
    $Trigger = New-ScheduledTaskTrigger -Daily -At $ScheduleTime
    $Principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive
    $Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -StartWhenAvailable -MultipleInstances Parallel

    ## Register the Scheduled Task
    Write-Host "Creating and registering scheduled task: '$TaskName' (Daily at $ScheduleTime)" -ForegroundColor Yellow
    Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Description "Automatically updates Spotify and reapplies BlockTheSpot patch." -Force | Out-Null

    Write-Host "---"
    Write-Host "✅ SETUP COMPLETE!" -ForegroundColor Green
    Write-Host "1. Spotify has been installed/updated with BlockTheSpot patch." -ForegroundColor Green
    Write-Host "2. The task '$TaskName' is set to run daily at $ScheduleTime." -ForegroundColor Green
    Write-Host "3. The scheduled task will automatically update Spotify and reapply the patch." -ForegroundColor Green
    Write-Host "--------------------------------------------------------"
} catch {
    Write-Host "⚠️ Warning: Failed to create scheduled task." -ForegroundColor Yellow
    Write-Host "Error details: $_" -ForegroundColor Yellow
    Write-Host "You can still use Spotify with BlockTheSpot, but auto-updates won't work." -ForegroundColor Yellow
}

# --- 3. PAUSE TO KEEP WINDOW OPEN ---
Write-Host ""
Write-Host "Press any key to close this window..." -ForegroundColor Cyan
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")